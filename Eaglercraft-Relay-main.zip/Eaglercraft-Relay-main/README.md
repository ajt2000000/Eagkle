# Eaglercraft-Relay
Host a eaglercraft Relay!
