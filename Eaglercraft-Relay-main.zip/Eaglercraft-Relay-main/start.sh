#!/bin/bash

chmod +x sp-relay.jar

java -jar sp-relay.jar
